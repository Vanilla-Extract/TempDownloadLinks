var fs = require('fs');

var effectJSON = {
    "parent": "item/generated",
    "textures": {
        "layer0": "",
        "layer1": ""
    }
};

var regular = ["empty", "mundane", "thick", "awkward", "night_vision", "invisibility", "leaping", "fire_resistance", "slowness", "water_breathing", "harming", "poison", "regeneration", "strength", "weakness", "luck", "turtle_master", "slow_falling"];

for (var i = 0; i < regular.length; i++) {
    var effect = regular[i];
    var effectLayer = "item/" + regular[i]
    var effectLayer0 = effectLayer + "_overlay";

    effectJSON.textures.layer0 = effectLayer0;
    effectJSON.textures.layer1 = effectLayer + "_potion"
    fs.writeFileSync("item/" + effect + "_potion.json", JSON.stringify(effectJSON));

    effectJSON.textures.layer1 = effectLayer + "_linger"
    fs.writeFileSync("item/" + effect + "_linger.json", JSON.stringify(effectJSON));

    effectJSON.textures.layer1 = effectLayer + "_splash"
    fs.writeFileSync("item/" + effect + "_splash.json", JSON.stringify(effectJSON));
}
