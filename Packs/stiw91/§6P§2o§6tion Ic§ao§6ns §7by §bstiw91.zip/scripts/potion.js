var fs = require('fs');

var potionPrefix = "type=item\nitems=potion\nmodel=item/";

var lingerPrefix = "type=item\nitems=lingering_potion\nmodel=item/";

var splashPrefix = "type=item\nitems=splash_potion\nmodel=item/";

var suffix = "\nnbt.Potion=minecraft:";

var regular = ["empty", "mundane", "thick", "awkward", "night_vision", "invisibility", "leaping", "fire_resistance", "slowness", "water_breathing", "harming", "poison", "regeneration", "strength", "weakness", "luck", "turtle_master", "slow_falling"];
var strong = ["leaping", "slowness", "harming", "poison", "regeneration", "strength", "turtle_master"];
var long = ["night_vision", "invisibility", "leaping", "fire_resistance", "slowness", "water_breathing", "poison", "regeneration", "strength", "weakness", "turtle_master", "slow_falling"];

for (var i = 0; i < regular.length; i++) {
    var effect = regular[i];

    fs.mkdirSync("potion/" + effect, { recursive: true });
    
    fs.writeFileSync("potion/" + effect + "/" + effect + "_potion.properties", potionPrefix + effect + "_potion" + suffix + effect);
    fs.writeFileSync("potion/" + effect + "/" + effect + "_linger.properties", lingerPrefix + effect + "_linger" + suffix + effect);
    fs.writeFileSync("potion/" + effect + "/" + effect + "_splash.properties", splashPrefix + effect + "_splash" + suffix + effect);

    if (strong.includes(regular[i])) {
        fs.writeFileSync("potion/" + effect + "/" + effect + "_potion_strong.properties", potionPrefix + effect + "_potion" + suffix + "strong_" + effect);
        fs.writeFileSync("potion/" + effect + "/" + effect + "_linger_strong.properties", lingerPrefix + effect + "_linger" + suffix + "strong_" + effect);
        fs.writeFileSync("potion/" + effect + "/" + effect + "_splash_strong.properties", splashPrefix + effect + "_splash" + suffix + "strong_" + effect);
    }

    if (long.includes(regular[i])) {
        fs.writeFileSync("potion/" + effect + "/" + effect + "_potion_long.properties", potionPrefix + effect + "_potion" + suffix + "long_" + effect);
        fs.writeFileSync("potion/" + effect + "/" + effect + "_linger_long.properties", lingerPrefix + effect + "_linger" + suffix + "long_" + effect);
        fs.writeFileSync("potion/" + effect + "/" + effect + "_splash_long.properties", splashPrefix + effect + "_splash" + suffix + "long_" + effect);
    }
}
