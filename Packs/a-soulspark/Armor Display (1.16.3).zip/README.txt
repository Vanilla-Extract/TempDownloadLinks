----------------------------------------------------------------------------------------------------
To install, put the "Armor Display (resource).zip" file in your resource packs folder
	%appdata%/.minecraft/resourcepacks/

You must enable the resource pack in-game for it to work.
----------------------------------------------------------------------------------------------------
The "Armor Display (data).zip" file must go to the "datapacks" folder in your world's folder. eg:
	"%appdata%/.minecraft/saves/My World/datapacks/

After putting the zip in the folder, no extra setup in-game is needed for the datapack.
----------------------------------------------------------------------------------------------------
There are two versions of the datapack: the normal one, and the "Simple" one.
Simple doesn't come with the Armor Toughness display, for a more basic look.
Only one may be used at a time.

There's only one resource pack, which can be used with either version of the datapack.
----------------------------------------------------------------------------------------------------